package com.coading.Arrays;
public class FindMinANDMaxElements {
	public static void main(String[] args) {
		int input []= {1, 2, 5, 5, 6, 6, 7, 2,89};

		int max=findMaxElements(input);
		System.out.println("Maximum Element is ::"+max);
		int min =findMinElements(input);
		System.out.println("Minimum Element is ::"+min);
		
	}

	private static int findMinElements(int[] input) {
		int minnum=input[0];
		for(int i=1;i<input.length;i++) {
			if(input[i]<minnum) {
				minnum=input[i];
			}
		}
		return minnum;
	}
	private static int findMaxElements(int[] input) {
		// TODO Auto-generated method stub
		int maxnum=input[0];
		for(int i=1;i<input.length;i++) {
			if(input[i]>maxnum) {
				maxnum=input[i];
			}
		}
		return maxnum;
		
	}

	

}
