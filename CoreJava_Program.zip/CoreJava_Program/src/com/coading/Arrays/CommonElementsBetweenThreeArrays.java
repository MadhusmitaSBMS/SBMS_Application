package com.coading.Arrays;

import java.util.ArrayList;

public class CommonElementsBetweenThreeArrays { 
	public static void main(String[] args) {
		 int ar1[] = {1, 5, 10, 20, 30,40, 80};
	     int ar2[] = {6, 7, 20,30, 80, 100};
		 int ar3[] = {3, 4, 15, 20, 30, 70, 80, 120};
		  System.out.println(findCommon(ar1, ar2, ar3));
		 
		 
	
	}

	private static ArrayList<Integer> findCommon(int[] ar1, int[] ar2, int[] ar3) {
		// TODO Auto-generated method stub
		int i = 0, j = 0, k = 0; 
		ArrayList<Integer> al=new ArrayList<>();
  
        while (i < ar1.length && j < ar2.length && k < ar3.length) 
        { 
             if (ar1[i] == ar2[j] && ar2[j] == ar3[k]) 
             {   
            	 al.add(ar1[i]);
            	 i++;
            	 j++; 
            	 k++; 
            	 } 
  
             else if (ar1[i] < ar2[j]) 
                 i++; 
  
             else if (ar2[j] < ar3[k]) 
                 j++; 
  
             else
                 k++; 
        }
		return al;
		
		
    } 
	
		

}
	

