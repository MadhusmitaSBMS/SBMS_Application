package com.coading.Arrays;

import java.util.Arrays;

public class ThirdLargestNumber {
	public static void main(String[] args) {
		//int [] Input = { 6, 8, 1, 9, 2, 1, 10};
		int [] Input = { 6, 8, 1, 9, 2, 1, 10, 12};
		int res=thirdLargestNumber(Input);
		System.out.println(res);
		
		
		
		
	}

	private static int thirdLargestNumber(int[] input) {
		// TODO Auto-generated method stub
		int i,j, count=0,temp=0;
		int n=input.length;
		for(i=0;i<n;i++) {
	    	for(j=i+1;j<n;j++) {
	    		if(input[i]>input[j]) {
	        		temp=input[i];
	        		input[i]=input[j];
	        		input[j]=temp;
	        	}	
	    	}
	    	
	    }
	    

		return input[n-3];
	}

}