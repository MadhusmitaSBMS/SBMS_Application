package com.coading.Arrays;

import java.util.LinkedHashSet;
import java.util.Set;

public class DuplicateElements {
	public static void main(String[] args) {
		//int []a= {1, 2, 5, 5, 6, 6, 7, 2};
		int [] a= {1, 2, 5, 5, 6, 6, 7, 2};
		Set<Integer> set=new LinkedHashSet<>();
		for(int store:a) {
			if(set.add(store)==true) {
				
				System.out.println(store);
			}
		}
		
		
	}

}
