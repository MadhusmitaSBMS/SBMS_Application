package com.coading.Arrays;

public class SmallestPairSum {
	public static void main(String[] args) {
		int []input={1, 7, 2, 9, 6};
		int n = input.length; 
	    System.out.println(smallestpairSum(input, n)); 
	}

	private static int smallestpairSum(int[] input, int n) {
		// TODO Auto-generated method stub
		int min =  Integer.MAX_VALUE;
		int secondMin =  Integer.MAX_VALUE; 
	    for (int j = 0; j < n; j++)  
	    { 
	  
	        if (input[j] < min) 
	        { 
	  
	            secondMin = min; 
	  
	            min = input[j]; 
	        } 
	  
	        else if ((input[j] < secondMin) && input[j] != min) 
	  
	            secondMin = input[j]; 
	    } 
	  
	    return (secondMin + min); 
	}

}
