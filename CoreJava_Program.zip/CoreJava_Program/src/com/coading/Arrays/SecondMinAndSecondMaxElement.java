package com.coading.Arrays;

public class SecondMinAndSecondMaxElement {
	public static void main(String[] args) {
		int [] input= {1, 2, 5, 9, 6, 4, 7, 2};
		int n, i,j, count=0,temp=0;
		for(i=0;i<input.length;i++) {
	    	for(j=i+1;j<input.length;j++) {
	    		if(input[i]>input[j]) {
	        		temp=input[i];
	        		input[i]=input[j];
	        		input[j]=temp;
	        	}	
	    	}
	    	
	    }
	    for(i=0;i<input.length;i++) {
	    	System.out.print(input[i] + " ");
	    	
	    }
	    System.out.println();
	    
	    System.out.println("The second min element is " +input[1] +" and second max element is :" + input[input.length-2]);
	    }
	}


