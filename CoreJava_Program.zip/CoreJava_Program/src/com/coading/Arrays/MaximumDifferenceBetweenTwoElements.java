package com.coading.Arrays;

public class MaximumDifferenceBetweenTwoElements {
	public static void main(String[] args) {
		//int [] input = { 2, 5, 1, 7, 3, 9, 5};
		 int  []input = { 9, 2, 12, 5, 4, 7, 3, 19, 5};
		int n = input.length; 
        System.out.println(MaximumDifferenceBetweenTwoElements(input, n)); 
	}

	private static int MaximumDifferenceBetweenTwoElements(int[] input, int n) {
		
		// TODO Auto-generated method stub
		int minEle = input[0]; 
        int maxEle = input[0]; 
        for (int i = 1; i < n; i++) { 
           minEle = Math.min(minEle, input[i]); 
            maxEle = Math.max(maxEle, input[i]); 
        } 
  
        return (maxEle - minEle); 
    } 
  
	}


