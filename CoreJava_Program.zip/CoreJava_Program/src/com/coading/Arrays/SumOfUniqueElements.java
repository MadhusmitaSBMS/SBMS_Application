package com.coading.Arrays;

import java.util.LinkedHashSet;
import java.util.Set;

public class SumOfUniqueElements {
	public static void main(String[] args) {
		int sum=0;
		//int input [] = {1, 6, 4, 3, 2, 2, 3, 8, 1};
		int input [] ={1, 1, 3, 2, 2, 3};
		Set<Integer> set=new LinkedHashSet<>();
		for(int data:input) {
			if(set.add(data)==true)	{
			sum=sum+data;
			}
		}
		System.out.println(sum);
		
		
		
		
		
	}

}
