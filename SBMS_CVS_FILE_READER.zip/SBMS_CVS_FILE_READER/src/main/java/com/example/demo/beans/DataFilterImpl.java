package com.example.demo.beans;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.example.demo.model.Product;
@Service
public class DataFilterImpl implements IDataFilter {


	@Override
	public List<Product> filterProduct(List<Product> prodList) {
		// TODO Auto-generated method stub
		
		return prodList.stream().filter(p-> p.getProdPrice()>=5000).collect(Collectors.toList());
	}

}
