package com.example.demo;

import java.io.IOException;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import com.example.demo.beans.CsvReader;
import com.example.demo.model.Product;

@SpringBootApplication
public class SbmsCvsFileReaderApplication {

	public static void main(String[] args) throws IOException {
		ConfigurableApplicationContext ctx=SpringApplication.run(SbmsCvsFileReaderApplication.class, args);
		CsvReader csvReader=ctx.getBean(CsvReader.class);
		 List<Product> fp=csvReader.readAndFilterProductData();
		 for(Product p:fp) {
			 System.out.println(p);
		 }
	}

}
