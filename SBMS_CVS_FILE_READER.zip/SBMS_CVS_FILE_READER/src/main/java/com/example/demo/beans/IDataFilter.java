package com.example.demo.beans;

import java.util.List;

import com.example.demo.model.Product;

public interface IDataFilter {
	public List<Product> filterProduct(List<Product> prodList);
}
