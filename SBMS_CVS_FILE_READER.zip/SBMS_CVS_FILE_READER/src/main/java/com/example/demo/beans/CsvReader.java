package com.example.demo.beans;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.model.Product;

@Service
public class CsvReader {
	private IDataFilter filter;

	public CsvReader(IDataFilter filter) {
		super();
		this.filter = filter;
	}
	 public List<Product> readAndFilterProductData() throws IOException{
		 List<Product> plist=new ArrayList<Product>();
		 FileReader fr=new FileReader(new File("Product.csv"));
		 BufferedReader bufferedReader=new BufferedReader(fr);
		 String linedata=bufferedReader.readLine();
		 while(linedata!=null) {
			 String [] split=linedata.split(",");
			 String pid=split[0];
			 String name=split[1];
			 String price=split[2];
			 Product p=new Product();
			 p.setProdId(Integer.parseInt(pid));
			 p.setProdName(name);
			 p.setProdPrice(Double.parseDouble(price));
			 
			 plist.add(p);
			 linedata=bufferedReader.readLine();
		 }
		 bufferedReader.close();
		return filter.filterProduct(plist);
		 
	 }
	

}
